package com.bean.JspController;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

/**
 * Created by BeanDu
 * Date: 2017-09-23 12:58
 * Project Name: demo2
 */

@RestController
public class Time {

    @RequestMapping("/time")
    public String time(){
        return "time : "+new Date().toLocaleString();
    }

}