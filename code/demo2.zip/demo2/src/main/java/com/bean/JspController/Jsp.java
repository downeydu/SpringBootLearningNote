package com.bean.JspController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Created by BeanDu
 * Date: 2017-09-23 13:02
 * Project Name: demo2
 */

@Controller
public class Jsp {

    @RequestMapping("/jsp/home")
    public String home(){ return "home"; }

}