package com.bean;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;


@SpringBootApplication
@ComponentScan("com.bean.init") //component在启动类的底层 这句话可以不加
public class Start {

	public static void main(String[] args) {
		SpringApplication.run(Start.class, args);
	}
}
