package com.bean.init;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/**
 * Created by BeanDu
 * Date: 2017-09-24 09:56
 * Project Name: demo9
 */

@Component
public class InitClass implements CommandLineRunner {
    private static final Logger logger = LoggerFactory.getLogger(InitClass.class);
    @Override
    public void run(String... args) throws Exception {
        System.out.println("<< system init >> ");
        for (int i = 0; i < 20; i++) {
            logger.info("现在开始报数:"+(i+1)+"号");
        }
    }
}

