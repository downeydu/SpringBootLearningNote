package com.bean.mapper;

import com.bean.entity.Person;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by BeanDu
 * Date: 2017-09-24 15:39
 * Project Name: demo11
 */

@Repository
@Mapper
public interface PersonMapper {

    public Person getPersonById(int id);

    public List<Person> getPersonList();

    public boolean delPerson(int id);

    public boolean updatePerson(int id,String name);

    public boolean insertPerson(String name,String passwd,String sysdate,double balance);

    public boolean transferAcount(int id,double money);

}