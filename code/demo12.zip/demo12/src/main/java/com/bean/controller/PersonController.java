package com.bean.controller;

import com.bean.entity.Person;
import com.bean.service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by BeanDu
 * Date: 2017-09-24 10:48
 * Project Name: demo10
 */

@RestController
public class PersonController {

    @Autowired
    private PersonService persev;

    @RequestMapping("/all")
    public List<Person> getPeronsList(){
        List<Person> ps = persev.getPersonList();
        return ps;
    }

    //用get把id传进去
    @RequestMapping(value = "/one/{id}",method = RequestMethod.GET)
    public Person getPeron(@PathVariable int id){
        Person ps = persev.getPerson(id);

        return ps;

    }

    @RequestMapping(value = "/update/{id}/{name}",method = RequestMethod.GET)
    public List<Person> update(@PathVariable int id,@PathVariable String name){
        persev.updatePerson(id,name);
        List<Person> ps = persev.getPersonList();
        return ps;
    }

    @RequestMapping(value = "/insert/{name}/{passwd}",method = RequestMethod.GET)
    public List<Person> insert(@PathVariable String name,@PathVariable String passwd){
        double balance = 100.0;
        Date datetime = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        persev.insertPerson(name,passwd,sdf.format(datetime),balance);
        List<Person> ps = persev.getPersonList();
        return ps;
    }

    @RequestMapping(value = "/del/{id}",method = RequestMethod.GET)
    public List<Person> del(@PathVariable int id){

        persev.delPerson(id);
        List<Person> ps = persev.getPersonList();
        return ps;
    }


    /**
     *
     * @param id1 转出帐号
     * @param id2 转进帐号
     * @param money 转账金额
     * @return
     */
    @Transactional   //transfer方法内所有sql都会在一个事务中执行
    @RequestMapping(value = "/transfer/{id1}/{id2}/{money}",method = RequestMethod.GET)
    public List<Person> transfer(@PathVariable int id1,@PathVariable int id2,@PathVariable double money){
        //模拟转账行为,id1转出金额,加入到id2帐号,id2为不存在账户,db报错,id1更新数据回滚.


        Person person1 = persev.getPerson(id1);
        persev.transferAccount(id1,person1.getBalance()-money);

        Person person2 = persev.getPerson(id2);
        persev.transferAccount(id2,person2.getBalance()+money);

        List<Person> ps = persev.getPersonList();
        return ps;
    }



}