package com.bean.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by BeanDu
 * Date: 2017-09-23 10:50
 * Project Name: demo1
 */

@RestController
public class Hello {

    @RequestMapping("/hello")
    public Map<String, String> index() {
        Map<String, String> hello = new HashMap<String, String>();
        hello.put("time", new Date().toString());
        hello.put("author", "Jack");
        return hello;
    }


}
