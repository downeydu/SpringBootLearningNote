package com.bean.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.Date;

/**
 * Created by BeanDu
 * Date: 2017-09-23 15:05
 * Project Name: demo3
 */
@Controller
public class FMController {

    @RequestMapping("/fm/home1")
    public String home(){
        return "home";
    }

    @RequestMapping("/fm/home2")
    public String home2(Model model){
        model.addAttribute("time", new Date().toLocaleString());
        return "home2";
    }

    @RequestMapping("/fm/home3")
    public ModelAndView home3(){
        //返回home3模版
        ModelAndView model = new ModelAndView("home3");
        model.addObject("time",new Date().toLocaleString());

        return model;
    }



}