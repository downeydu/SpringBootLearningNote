package com.bean.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Created by BeanDu
 * Date: 2017-09-23 16:26
 * Project Name: demo5
 */

@WebServlet
public class HelloServlet extends HttpServlet{

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("<< do get >>");
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("<< do post >>");
        PrintWriter pw = resp.getWriter();
        String name = req.getParameter("name");
        pw.print("hello "+name);
        pw.close();
    }
}