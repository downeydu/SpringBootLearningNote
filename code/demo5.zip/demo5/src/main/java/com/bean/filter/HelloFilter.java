package com.bean.filter;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.xml.ws.WebFault;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Created by BeanDu
 * Date: 2017-09-23 16:29
 * Project Name: demo5
 */

@WebFilter
public class HelloFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        System.out.println("<< filter init >>");
    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse resp, FilterChain filterChain) throws IOException, ServletException {
        System.out.println("<< do filter >>");
        String name = req.getParameter("name");
        String passwd = req.getParameter("passwd");
        if(name==null  || passwd==null || !passwd.equals("1111") ){

            System.out.println("find error");
            PrintWriter pw  = resp.getWriter();
            pw.print("find error web");
            pw.close();

        }else{
            System.out.println("welcome bean!!!");
            filterChain.doFilter(req,resp);

        }
    }

    @Override
    public void destroy() {
        System.out.println("<< filter destroy >>");
    }
}