package com.bean;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * Created by BeanDu
 * Date: 2017-09-24 09:35
 * Project Name: demo8
 */
@Configuration
public class Config extends WebMvcConfigurerAdapter {
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        //handler里面地址可以自定义映射,location里面为实际的目录
        registry.addResourceHandler("/skyimgs/**").addResourceLocations("classpath:/imgs/");
    }
}