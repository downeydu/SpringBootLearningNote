package com.bean.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by BeanDu
 * Date: 2017-09-24 09:20
 * Project Name: demo8
 */

@RestController
public class Hello {

    @RequestMapping("/hello")
    public String hello(){
        return "home1";
    }
}