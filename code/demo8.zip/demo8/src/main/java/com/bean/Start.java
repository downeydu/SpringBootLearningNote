package com.bean;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Start {
	//静态资源加载,目录优先级  WEB-INF.resource >resource > static >public
	public static void main(String[] args) {
		SpringApplication.run(Start.class, args);
	}
}
