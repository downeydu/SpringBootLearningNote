package com.bean.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by BeanDu
 * Date: 2017-09-23 18:04
 * Project Name: demo7
 */
@RestController
public class Hello {

    @RequestMapping("/api")
    public String api(){
        System.out.println("api api api");
        return "I am class";
    }
}