package com.bean.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by BeanDu
 * Date: 2017-09-23 18:04
 * Project Name: demo7
 */
@RestController
public class Bean {

    @RequestMapping("/bean")
    public String api(){
        return "I am Bean";
    }
}