package com.bean.service;

import com.bean.entity.Person;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

/**
 * Created by BeanDu
 * Date: 2017-09-24 10:47
 * Project Name: demo10
 */

@Service
public class PersonService {

    @Autowired
    private JdbcTemplate jdbctpl; //idea2016bug:需要修改idea.properties,添加:idea.spring.boot.filter.autoconfig=false

    public List<Person> getPersonList() {
        return jdbctpl.query("select * from person", new RowMapper<Person>() {
            @Override
            public Person mapRow(ResultSet res, int i) throws SQLException {
                Person person = new Person();
                person.setId(res.getString("id"));
                person.setName(res.getString("name"));
                person.setPasswd(res.getString("passwd"));
                person.setRegtime(res.getString("regtime"));
                return person;

            }
        });
    }

    public List<Person> getPerson(int id) {
        return jdbctpl.query("select * from person where id = ?",new RowMapper<Person>() {
            @Override
            public Person mapRow(ResultSet res, int i) throws SQLException {
                Person person = new Person();
                person.setId(res.getString("id"));
                person.setName(res.getString("name"));
                person.setPasswd(res.getString("passwd"));
                person.setRegtime(res.getString("regtime"));
                return person;

            }
        },id);
    }





}