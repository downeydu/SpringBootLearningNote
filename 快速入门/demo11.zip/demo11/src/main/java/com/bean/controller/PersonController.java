package com.bean.controller;

import com.bean.entity.Person;
import com.bean.service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by BeanDu
 * Date: 2017-09-24 10:48
 * Project Name: demo10
 */

@RestController
public class PersonController {

    @Autowired
    private PersonService persev;

    @RequestMapping("/persons")
    public List<Person> getPeronsList(){
        List<Person> ps = persev.getPersonList();
        return ps;
    }

    //用get把id传进去
    @RequestMapping(value = "/person/{id}",method = RequestMethod.GET)
    public Person getPeron(@PathVariable int id){
        Person ps = persev.getPerson(id);

        return ps;

    }

}