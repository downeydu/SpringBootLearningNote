package com.bean.service;

import com.bean.entity.Person;
import com.bean.mapper.PersonMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

/**
 * Created by BeanDu
 * Date: 2017-09-24 10:47
 * Project Name: demo10
 */

@Service
public class PersonService {

    @Autowired
    private JdbcTemplate jdbctpl; //idea2016bug:需要修改idea.properties,添加:idea.spring.boot.filter.autoconfig=false

    @Autowired
    private PersonMapper pm;


    public Person getPerson(int id){
        return pm.getPersonById(id);
    }

    public List<Person> getPersonList(){
        return pm.getPersonList();
    }




}